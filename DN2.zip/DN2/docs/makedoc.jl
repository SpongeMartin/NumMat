using Weave

Weave.weave("DN2/test/demo.jl", doctype="minted2pdf",out_path="DN2/docs/build")