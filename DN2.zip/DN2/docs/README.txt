Martin Starič

Gauss-Legendrove kvadrature
Projekt vsebuje funkcije za sestavljeno Gauss-Legendrovo kvadraturno formulo za integrale, ki tečejo od 0 do h. Bolj podrobno je raziskan integral od 0 do 5 sin(x)/x

Kodo zaženemo tako:
1. V Julia REPL gremo v način pkg in napišemo activate DN2
2. Nato lahko sledimo zgledu demo.jl

.tex generiramo s pomočjo makedoc.jl, ki uporablja Weave.